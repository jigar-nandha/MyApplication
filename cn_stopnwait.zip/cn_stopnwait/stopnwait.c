
/**************************************************

file: demo_rx.c
purpose: simple demo that receives characters from
the serial port and print them on the screen,
exit the program by pressing Ctrl-C

compile with the command: gcc demo_rx.c rs232.c -Wall -Wextra -o2 -o test_rx

**************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#ifdef _WIN32
#include <Windows.h>
#else
#include <unistd.h>
#endif

#include "rs232.h"



int main()
{
  int i, n,size,j=1,flag=0,
      cport_nr=0,        /* /dev/ttyS0 (COM1 on windows) */
      bdrate=9600;       /* 9600 baud */

  unsigned char buf[4096],checksum=0;
  char msg[10];

  char mode[]={'8','N','1',0};


  if(RS232_OpenComport(cport_nr, bdrate, mode))
  {
    printf("Can not open comport\n");

    return(0);
  }

  while(1)
  {
    size=0;
    checksum=0;
    flag=0;
    i=0;
    
    n = RS232_PollComport(cport_nr, buf, 4095);

    if(n > 0)
    {
      buf[n] = 0;   /* always put a "null" at the end of a string! */

      /*for(i=0; i < n; i++)
      {
        if(buf[i] < 32)   replace unreadable control-codes by dots 
        {
          buf[i] = '.';
        }
      }*/
      //printf("%s \n",buf);
      
      size = buf[0];
      
      for(i=1;i<=size;i++)
      	printf("%c",buf[i]);
      printf("\n");
      
      printf("%d \n",size);
      for(j=1;j<=size;j++)
      {
      	checksum = checksum + buf[j];
      }
      
      /*for(i=1;i<=n;i++)
      	printf("%d ",buf[i]);*/
      
      printf("\n");
      printf("%d %d \n",buf[j+1],checksum);
      if(checksum == buf[j+1])
      {
      	strcpy(msg,"okay");
      	flag=1;
      }
      printf("\n");
      /*for(j=1;j<=size;j++)
      {
      	printf("%c",buf[j]);
      }*/
      printf(" \n");
      
      if(flag==1)
      {
      	  if(RS232_OpenComport(cport_nr, bdrate, mode))
  	  {
    		printf("Can not open comport\n");
		return(0);
  	  }
  	  
  	      RS232_cputs(cport_nr, msg);

    	      printf("sent: %s\n\n", msg);

    	      usleep(1000000);  /* sleep for 1 Second */

      }

      //printf("received %i bytes: %s\n", n, (char *)buf);
      }

#ifdef _WIN32
    Sleep(100);
#else
    usleep(100000);  /* sleep for 100 milliSeconds */
#endif
  }

  return(0);
}

