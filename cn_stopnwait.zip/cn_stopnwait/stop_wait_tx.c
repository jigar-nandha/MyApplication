
/**************************************************

file: demo_tx.c
purpose: simple demo that transmits characters to
the serial port and print them on the screen,
exit the program by pressing Ctrl-C

compile with the command: gcc demo_tx.c rs232.c -Wall -Wextra -o2 -o test_tx

**************************************************/

#include<stdlib.h>
#include<stdio.h>
#include<string.h>

#ifdef _WIN32
#include <Windows.h>
#else
#include <unistd.h>
#endif

#include "rs232.h"



int main()
{
  int i=0,len=0,k=0,n=0,
      cport_nr=0,        /* /dev/ttyS0 (COM1 on windows) */
      bdrate=9600;       /* 9600 baud */
	int c2 = 0;
  char mode[]={'8','N','1',0};
  
 
  if(RS232_OpenComport(cport_nr, bdrate, mode))
  {
    printf("Can not open comport\n");
    return(0);
  }
  long count;
  char c[300];
  char msg[400];
  unsigned char buf[10];
  int checksum=0,n_chars;
  while(1)
  {	
  	//i=0;
  	count = 0;
  	checksum = 0;
  	printf("\nEnter Message: \n");
  	gets(c);
  	printf("%s\n",c);
  	len=strlen(c);
  	
  	c2++;
  	
  	for(k = 0; k < len; k++){
  		checksum += c[k];
  	}
  	//count = count % 256;
  	//checksum = (char)count;
  	n_chars = len;
  	msg[0] = n_chars;
  	printf("%d \n",msg[0]);
  	
  	//strcat(msg ,(const char *)n_chars);
  	
  	strcat(msg ,c);
  	if((c2 % 4) == 0)
  		msg[len+2] = checksum+1;
  	else
  		msg[len+2] = checksum;
  		
  	printf("%d \n",msg[len+2]);
  	//strcat(msg ,(const char *)checksum);
  	
    for(k = 0; k <= len+6; k++){
    	RS232_SendByte(cport_nr,msg[k]);
    }
    
    printf("sent: %s\n",msg);
    count = 0;
   while(1)
   {
      n = RS232_PollComport(cport_nr, buf, 4095);

		if(n > 0)
		{
		  buf[n] = 0;   /* always put a "null" at the end of a string! */

		  for(i=0; i < n; i++)
		  {
		    if(buf[i] < 32)  /* replace unreadable control-codes by dots */
		    {
		      buf[i] = '.';
		    }
		  }
		  int ack = strcmp((char *)buf ,"okay");
		  if(ack == 0){
		  	printf("received %i bytes: %s\n", n, (char *)buf);
		  	break;
		  }
		  
		  
		  
		}
/*
	#ifdef _WIN32
		Sleep(1);
	#else
		usleep(1);  /* sleep for 100 milliSeconds */
	/*#endif*/
	count ++;
	if(count == 10000000){
		if(n <= 0){
			if(RS232_OpenComport(cport_nr, bdrate, mode))
		    {
				printf("Can not open comport\n");
				return(0);
		    }
			msg[len + 2] = checksum;
			for(k = 0; k <= len+6; k++){
				RS232_SendByte(cport_nr,msg[k]);
			}
		 	printf("sent again: %s\n",msg);
		 	count = 0;
		}
	}
	}
	memset(msg,'\0',400);
	memset(c,'\0',300);
	
	
  }

  return(0);
}

